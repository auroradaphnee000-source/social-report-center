# PenSignal 搜索广告落地页交接说明

更新：2026-10-25（Asia/Shanghai）。正式页面已经上线：
https://pensignal.deflametech.com/en/bulk-seo-articles

本目录是独立的静态交接稿，不是正式 Next.js 仓库。**本版已完成样例文章全文修订、落地页更新与交接打包；尚未部署至正式站，也没有覆盖线上文章。** 用户已确认注册、首次生成和付款路径均已 OK；本次未重新注册或付款。

先打开 `preview.html` 看新版落地页；点击其中的全文按钮会打开本包的修订文章。正式接入用 `index.html` 和 `sample-article-content.html`，不要把本地预览文件名当作线上路由。

## 本次页面改动

- 首屏保留免费注册主按钮，次按钮改为 `See a real article`，跳到 `#sample`。
- 真实文章展示区放在首屏能力条之后、工作流程之前；替换原来的编辑器骨架示意区。
- 展示真实标题、短摘录、内容格式说明和 `Read the full article`。全文在新标签页打开，无需注册，落地页保留供用户返回。
- 样例来自自有博客，明确标为 `GENERATED WITH PENSIGNAL · EDITED SAMPLE`，说明已编辑修订；不标为未经编辑的生成稿或第三方客户案例。
- 品牌头尾复用正式站 logo、字标，保留语言入口；样例卡展示原文章配图和摄影师来源，沿用现有蓝橙视觉。
- 样例区保留一个试用按钮，沿用 `product_explore`，六个注册入口总数不变。
- 同步正式站最新价格、邮件验证后试用条件和额外积分规则。
- 注册按钮添加固定 `data-cta-id`，正文带 `data-landing-id="bulk_seo_articles"`。样例全文链接另有 `data-sample-id` 和 `data-sample-location`。

公开样例：
https://pensignal.deflametech.com/en/blog/tutorials/mastering-multilingual-keyword-research-for-global-reach

## 2026-10-25 正式站复核

线上复核依据为公开 HTML、公开落地页脚本、robots.txt 及用户提供的现有落地页长截图；落地页、首页、文章、联系、条款、隐私均返回 HTTP 200。此前线上浏览器自动化停止，因此没有据此确认线上交互；本次另对独立本地预览做响应式渲染与交互检查，不能替代正式接入后的注册、Cookie 和埋点验收。HTTP 可访问也不等于 Ads 审核通过。

| 检查项 | 结果 |
| --- | --- |
| 产品价值 | 首页已明确 SEO agencies / content teams、关键词到文章、批量与多语言；落地页与之相符 |
| 套餐价格 | 首页与落地页一致：10 credits / $10，50 / $45，100 / $75，均为 USD；标准文章 1 credit，最低 $0.75 / 篇 |
| 额外消耗 | 高级 AI 图片每张额外 0.5 credit；可选关键词分析每次 1 credit；不能把 10 免费 credits 宣传为必得 10 篇带全部附加功能的文章 |
| 免费条件 | 邮件验证后发放，受资格限制；无需银行卡；本地旧稿已同步 |
| 品牌域名 | 所检查页面的品牌、canonical 与站内链接均使用 pensignal.deflametech.com；首页示意地址也已改为该域名 |
| 公司与法律入口 | 落地页列 DeFlame Tech Co. Limited，Contact / Terms / Privacy 均可访问；这里只核对呈现，不代表法律合规审查 |
| 真实证明 | 正式落地页仍只有示意工作台与编辑器骨架；本次本地稿已增加真实文章链接，待接入 |
| 搜索抓取 | 落地页为 noindex, follow；robots.txt 未封锁该落地页。付费专用页可保留 noindex；AdsBot 实际访问与审核仍需在 Ads 核实 |

## 已完成的文章修复

修订稿约 1,200 个英文词，保留原题和主题，改为七步流程。以下修复均已落实到 `sample-article-content.html`，不只是修改建议：

| 原问题 | 本版处理 |
| --- | --- |
| 积分“永不过期” | 改为正常使用有效，并注明连续 24 个月不活跃可审查、移除，链接现行条款 |
| 50 篇同时生成 | 改为每批最多 50 篇，最多 10 篇并发 |
| AI 分数 <50% 即可安全发布 | 删除阈值发布流程，换为事实、来源、产品可操作性及本地语言审阅 |
| 无法核实的市场份额、翻译单价及节省金额 | 删除，改为清楚标注的示例 brief 和当前自家积分价格，不补造来源 |
| 搜索引擎排名因素／标题字数“硬上限”表格 | 删除，换为关键词意图与编辑 brief 对照表 |
| 本产品可直接查看关键词排名、滚动深度等 | 区分 PenSignal 浏览量报告、Search Console 搜索报告与网站转化分析 |
| 来源过于笼统 | 相关段落链接 Google Keyword Planner、Search Central 与 Search Console 的具体官方文档 |
| 原始生成证明不清楚 | 文章与落地页都明确为 PenSignal 生成后经过编辑的样例 |
| 老社交分享文案宣传检测率 | 提供一致的新 title / description / OG / Twitter 元信息 |

正文中仍使用原摄影师 Tobias Dziuba 的一张 Pexels 配图，并保留原作品页署名；本包另存本地图片用于离线预览。删除了旧文中无依据的“统治搜索结果”等结论。

## 文章替换方法

1. 在现有博客中找到原记录，保持 URL、slug、作者和原发布时间不变：
   `/en/blog/tutorials/mastering-multilingual-keyword-research-for-global-reach`。
2. 用 `sample-article-content.html` 的完整内容替换文章正文。该文件只有正文容器，没有重复 H1、页面导航、整页 `<html>` 或追踪脚本；可供现有 HTML 内容渲染器接入，不要用整页预览 HTML 覆盖 CMS 正文。
3. 按现有 CMS 字段映射 `sample-article-metadata.json` 中的标题、描述和 canonical。同步 OG / Twitter 标题与描述，覆盖旧的 AI 检测率文案；如记录更新时间，填写实际部署日期。JSON 是字段交接说明，不假定能直接导入未知 CMS。
4. 原发布时间为 `2026-09-11T04:50:28.447825+00:00`；本地修改日期为 2026-10-25。不要把修改日期冒充原发布时间。
5. 生产正文配图保留现有 `/api/uploads/111ca2f5-7789-487e-b6e4-11e023d59a05.jpeg` 地址，无需重新上传。`sample-article.html` 只是本地完整预览，使用打包图片，并带返回本地落地页的链接。
6. 如现有博客样式不足，可接入 `article.css` 中 `.ps-article-body` 命名空间下的规则；`.sample-document` 规则仅供独立预览壳使用。保留表格的横向滚动容器与可见焦点样式。
7. 不复制原文中嵌入的 1×1 跟踪图片或旧文章 ID 到新正文。现有博客渲染器的页面级埋点由站点层保留并验收，本包没有增加分析脚本。

## 网站其他残留文案

- **Contact** 仍以“industry-low AI detection rates”介绍产品，并写“support English and Mandarin Chinese”。应改为当前“关键词到批量 SEO 文章”的价值；若后者指界面语言，明确说明，避免与 36 种文章语言／地区变体混淆。
- **首页 JSON-LD / 全站元信息** 仍有“industry-low AI detection rates”和旧试用描述，建议与可见定位及邮件验证条件同步。免费试用与付费套餐应分别描述，USD 套餐保持清楚。
- **首页付款标识** 可读区域只突出 Alipay / Alipay HK，而落地页 FAQ 已说 Visa / Mastercard。既然卡付款已由用户确认可用，应在首页价格区也清楚列出，减少海外访客疑虑；无需重新更换收款方案。

建议 Contact 简介：`PenSignal helps SEO agencies and content teams turn keywords into article drafts in batches, across 36 language and regional variants. Standard generation uses one credit per article, with credit packs starting at $10 USD.`

## 接入现有 Next.js 网站

1. 在现有 `/en/bulk-seo-articles` 路由应用本次改动，复用现有品牌、locale 切换与根布局。将正文转成 React 组件、样式局部化；不要整页嵌入另一份 HTML 或重复导航。
2. 将新 `#sample` 区放到首屏能力条之后，删掉原 `SEE THE PRODUCT` 骨架区。保留首屏工作台的 `Illustrative preview` 标注，后续有真实产品截图再替换。
3. 保留生产页面现有 UTM / gclid / gbraid / wbraid 传递。公开脚本里的注册链接组件当前只接收 `locale`、`className`、`children`，接入时需显式接收并转发 `ctaId` 到最终 `<a data-cta-id={ctaId}>`；只给组件外层加属性会被丢掉。把入口信息持久保存以支持注册及 Google 登录回跳。
4. 六个注册 `cta_id` 为 `header_start_free`、`hero_start_free`、`features_try_workflow`、`product_explore`、`pricing_create_account`、`footer_start_free`。本地稿只提供选择器，**没有发送事件或新增埋点脚本**。
5. 新增样例全文链接可在 GTM 用 `a[data-sample-id]` 识别，选配 `landing_sample_click`，参数 `landing_id`、`sample_id`、`location`。只用于页面分析，不设为 Ads 主要转化；首屏跳转锚点不当作全文阅读。
6. 当前生产 HTML 显示 **GTM-KSSX8WW5**、**G-VT2QCR9CVN**、**AW-18091368393**。旧说明里的 GTM-W9GJ5DT7 已不适用；先确认用户编辑的是当前容器。根布局同时存在同意后加载的 GTM 与独立 gtag，另有同站 `/gtm/`、`/ga` 转发，**这不证明已重复上报或一定能回传**。GTM Preview / Tag Assistant 与 GA4 DebugView 需确认各自职责、转发可用、单次 page_view 及业务事件去重，不要再叠加一套基础标签。
7. `index.html` 的全文按钮已经指向原来的正式博客 URL；保持它，先发布修订正文，再发布落地页引用。`preview.html` 仅为离线审阅，把这个按钮改连本包 `sample-article.html`，不能作为生产路由版本。
8. 图片接入时复用现有资源：`assets/logo.webp` → `/logo.webp`；`assets/name.webp` → `/name.webp`；`assets/keyword-research-notes.jpeg` → 上述现有文章配图地址。本地相对路径不可直接复制到多层 Next.js 路由后当作生产图片地址。
9. 正式发布后，桌面／手机核对全文打开、返回落地页、注册六入口、邮件验证条件、语言菜单和 Cookie 选择。静态检查与本地渲染不能代替真实站点的业务及埋点验收。

## 文件与验证

- `index.html`、`styles.css`：用于接入正式落地页的静态稿，样例链接保留正式 URL。
- `preview.html`：本地落地页预览，全文按钮打开本包修订稿。
- `sample-article-content.html`：替换现有文章的正文 HTML。
- `sample-article-metadata.json`：文章标题、描述、URL、原发布时间和字段映射说明。
- `sample-article.html`、`article.css`：完整文章的本地预览及命名空间样式。
- `assets/`：正式站现有品牌资源、原文章图片的本地副本。
- `preview.png`、`preview-mobile.png`：本版落地页桌面／手机完整预览。
- `article-preview.png`、`article-preview-mobile.png`：本版文章桌面／手机完整预览。
- `pensignal-bulk-seo-landing.zip` 及上级 `pensignal-landing.zip`：内容相同；不包含压缩包自身、WLB 私人材料、浏览器资料或依赖目录。

验证记录见随包 `verification.json`。本地检查覆盖 320 / 390 / 768 / 1024 / 1440 像素宽度的落地页和文章，包含图片加载、无整页横向溢出、六注册入口、样例锚点、全文新标签页、FAQ 展开和表格结构。尚未部署正式站，注册／支付／GTM 沿用现有正式系统并在部署后验收。
